import cv2
import time
import socket
from PIL import Image,ImageTk
from FaceRecognition import Face
import baiduasr
import threading
from tts import tts
import prediction

socket_client = ''
socket_client2 = socket.socket()
socket_client2.connect(('192.168.1.100',2002))
def TCPClient():
    global socket_client
    socket_client = socket.socket()
    socket_client.connect(('192.168.1.100',2001))
    while True:
        data = socket_client.recv(1024).decode()
        print('')
        print(data)
        time.sleep(0.1)
if __name__ == '__main__':
    th1 = threading.Thread(target=TCPClient)
    th1.setDaemon(1)
    th1.start()
    time.sleep(0.1)
    tts("人脸识别开始请对准摄像头")
    name,confidence = Face()
    confidence = "{0}%".format(round(205-confidence))
    print("您的名字是",name)
    print("您的匹配度为",confidence)
    faceimg = cv2.imread('image.jpg')
    cv2.imshow("img",faceimg)
    cv2.waitKey(3000)
    cv2.destroyAllWindows()
    while True:
        tts("语音识别开始请按下回车键")
        input("语音识别开始请按下回车键：")
        msg = ''
        baiduasr.record()
        data = baiduasr.asr_updata()
        t = data.split(', ')
        print(t)
        for i in range(len(t)):
            if '一号' in t[i]:
                msg = 'A'
                print(msg)
                socket_client.send(msg.encode())
            elif "二号" in t[i]:
                msg = 'B'
                print(msg)
                socket_client.send(msg.encode())
            elif "三号" in t[i]:
                msg = 'C'
                print(msg)
                socket_client.send(msg.encode())
            elif "四号" in t[i]:
                msg = 'D'
                print(msg)
                socket_client.send(msg.encode())
            elif "管控" in t[i]:
                msg = 'fl'
                print(msg)
                socket_client.send(msg.encode())
            elif "发放" in t[i]:
                msg = 'wz'
                print(msg)
                socket_client.send(msg.encode())


                prediction.remove_result()
                print('waiting......')

                while True:
                    data = socket_client2.recv(1024).decode('utf-8')

                    print(data)
                    m = ''
                    if data == 'sb':
                        src_roi = cv2.imread("D:/VisionMaster/image.jpg")
                        label,pred_class = prediction.modelpre(src_roi)
                        print(label,pred_class)
                        prediction.showResult(src_roi,pred_class)
        #'fangbianmian', 'fenda', 'guantou', 'kele', 'kuangquanshui', 'maojin', 'mianbao', 'pingguo', 'xifashui', 'xuebi', 'yagao', 'zhijin'
                        if label == 0:
                            m = 'fangbianmian'
                        elif label == 1:
                            m = 'fenda'
                        elif label == 2:
                            m = 'guantou'
                        elif label == 3:
                            m = 'kele'
                        elif label == 4:
                            m = 'kuangquanshui'
                        elif label == 5:
                            m = 'maojin'
                        elif label == 6:
                            m = 'mianbao'
                        elif label == 7:
                            m = 'pingguo'
                        elif label == 8:
                            m = 'xifashui'
                        elif label == 9:
                            m = 'xuebi'
                        elif label == 10:
                            m = 'yagao'
                        elif label == 11:
                            m = 'zhijin'
                        socket_client2.send(m.encode())
                        data = ''



























