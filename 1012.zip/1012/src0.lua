-- Version: Lua 5.3.5
-- 此线程为主线程，可调用任何指令

local ip="192.168.1.100"
local port=2004
local err=0
local socket=0
local code_num = 0
Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
while true do
	::create_server::
	err, socket = TCPCreate(false, ip, port)
	if err ~= 0 then
		print("Failed to create socket, re-connecting")
		Sleep(1000)
		goto create_server
	end
	err = TCPStart(socket, 0)
	if err ~= 0 then
		print("Failed to start server, re-connecting")
		TCPDestroy(socket)
		Sleep(1000)
		goto create_server
	end
	while true do
		err, buf = TCPRead(socket, 0,"string")
		data =buf.buf
		print("\r".."接收的内容:"..data.."\r")
		if err ~= 0 then
			print("Failed to read data, re-connecting")
			TCPDestroy(socket)
			Sleep(1000)
			break
		end
		if  data== "fl" then
			code_num = code_num +1
			if code_num == 1 then
				Jump(P2,"Start=220,ZLimit=220,End=220,SYNC=1")
			elseif code_num == 2 then
				Jump(P3,"Start=220,ZLimit=220,End=220,SYNC=1")
			elseif code_num == 3 then
				Jump(P4,"Start=220,ZLimit=220,End=220,SYNC=1")
			elseif code_num == 4 then
				Jump(P5,"Start=220,ZLimit=220,End=220,SYNC=1")
			elseif code_num == 5 then
				Jump(P6,"Start=220,ZLimit=220,End=220,SYNC=1")
			elseif code_num == 6 then
				Jump(P7,"Start=220,ZLimit=220,End=220,SYNC=1")
			end
			DO(1,1)
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"paiewm")
			
		elseif data == "fh" then
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			if code_num == 1 then
				Jump(P2,"Start=220,ZLimit=220,End=220,SYNC=1")
			elseif code_num == 2 then
				Jump(P3,"Start=220,ZLimit=220,End=220,SYNC=1")
			elseif code_num == 3 then
				Jump(P4,"Start=220,ZLimit=220,End=220,SYNC=1")
			elseif code_num == 4 then
				Jump(P5,"Start=220,ZLimit=220,End=220,SYNC=1")
			elseif code_num == 5 then
				Jump(P6,"Start=220,ZLimit=220,End=220,SYNC=1")
			elseif code_num == 6 then
				Jump(P7,"Start=220,ZLimit=220,End=220,SYNC=1")
			end
			DO(1,0)
			TCPWrite(socket,"ewmfw")
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			
		elseif data == "A1" then
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P9,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"ewmfw")
		elseif data == "B1" then
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P10,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"ewmfw")
		elseif data == "C1" then
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P11,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"ewmfw")
		elseif data == "D1" then
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P12,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"ewmfw")
		elseif data == "diu" then
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P13,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"wzfw")
		elseif data == "A2" then
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P9,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"wzfw")
		elseif data == "B2" then
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P10,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"wzfw")
		elseif data == "C2" then
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P11,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"wzfw")
		elseif data == "D2" then
			Jump(P8,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,1)
			Jump(P12,"Start=220,ZLimit=220,End=220,SYNC=1")
			DO(1,0)
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
			TCPWrite(socket,"wzfw")
		elseif data == "6" then
			Jump(P1,"Start=220,ZLimit=220,End=220,SYNC=1")
		end
	end
end